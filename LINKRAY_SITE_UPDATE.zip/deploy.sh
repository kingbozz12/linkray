#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_DIR="${1:-$PWD}"
SITE_DIR="$PROJECT_DIR/public/linkray-site"
SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)/site"
BACKUP_DIR="/root/linkray-site-backups"

[ -d "$PROJECT_DIR/.git" ] || { echo "Не найден Git-проект LinkRay: $PROJECT_DIR"; exit 1; }
[ -d "$SITE_DIR" ] || { echo "Не найден сайт: $SITE_DIR"; exit 1; }
[ -f "$SOURCE_DIR/index.html" ] || { echo "В ZIP нет сайта"; exit 1; }

mkdir -p "$BACKUP_DIR"
BACKUP="$BACKUP_DIR/linkray-site-$(date +%Y%m%d-%H%M%S).tar.gz"
tar -czf "$BACKUP" -C "$SITE_DIR" .

find "$SITE_DIR" -mindepth 1 -maxdepth 1 -exec rm -rf {} +
cp -a "$SOURCE_DIR/." "$SITE_DIR/"
chmod -R u=rwX,go=rX "$SITE_DIR"

git add -A -- public/linkray-site
if ! git diff --cached --quiet -- public/linkray-site; then
  git commit -m "Update LinkRay website"
  git push origin HEAD:main
fi

if docker compose version >/dev/null 2>&1; then
  docker compose up -d --build app
else
  docker-compose up -d --build app
fi

curl -fsS --max-time 20 http://127.0.0.1:3000/ >/dev/null
echo
echo "========================================"
echo "САЙТ LINKRAY УСТАНОВЛЕН"
echo "Резервная копия: $BACKUP"
echo "Проверь: https://linkray.ru"
echo "========================================"
