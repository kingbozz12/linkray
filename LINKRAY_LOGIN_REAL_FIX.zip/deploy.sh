#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_DIR="${1:-/opt/linkray}"
PATCH_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKUP_DIR="/root/linkray-site-backups"
STAMP="$(date +%Y%m%d-%H%M%S)"

cd "$PROJECT_DIR"

[ -d .git ] || { echo "Не найден Git-проект LinkRay: $PROJECT_DIR"; exit 1; }
[ -f src/linkrayWebsiteRoutes.js ] || { echo "Нет src/linkrayWebsiteRoutes.js"; exit 1; }
[ -f public/linkray-site/index.html ] || { echo "Нет public/linkray-site/index.html"; exit 1; }

mkdir -p "$BACKUP_DIR"
tar -czf "$BACKUP_DIR/linkray-auth-before-$STAMP.tar.gz" \
  src/linkrayWebsiteRoutes.js \
  public/linkray-site

cp "$PATCH_DIR/src/linkrayWebsiteRoutes.js" src/linkrayWebsiteRoutes.js
cp "$PATCH_DIR/public/linkray-site/web-auth.js" public/linkray-site/web-auth.js
cp "$PATCH_DIR/public/linkray-site/web-auth.css" public/linkray-site/web-auth.css
cp "$PATCH_DIR/public/linkray-site/cabinet.html" public/linkray-site/cabinet.html
cp "$PATCH_DIR/public/linkray-site/cabinet.css" public/linkray-site/cabinet.css
cp "$PATCH_DIR/public/linkray-site/cabinet.js" public/linkray-site/cabinet.js

python3 - <<'PY'
from pathlib import Path

index = Path("public/linkray-site/index.html")
text = index.read_text(encoding="utf-8")

css = '<link rel="stylesheet" href="/linkray-site/web-auth.css?v=auth-v1">'
js = '<script src="/linkray-site/web-auth.js?v=auth-v1" defer></script>'

if "web-auth.css" not in text:
    marker = "</head>"
    if marker not in text:
        raise SystemExit("В index.html не найден </head>")
    text = text.replace(marker, f"  {css}\n{marker}", 1)

if "web-auth.js" not in text:
    marker = "</body>"
    if marker not in text:
        raise SystemExit("В index.html не найден </body>")
    text = text.replace(marker, f"  {js}\n{marker}", 1)

index.write_text(text, encoding="utf-8")
PY

node --check src/linkrayWebsiteRoutes.js
node --check public/linkray-site/web-auth.js
node --check public/linkray-site/cabinet.js

git add -- \
  src/linkrayWebsiteRoutes.js \
  public/linkray-site/index.html \
  public/linkray-site/web-auth.js \
  public/linkray-site/web-auth.css \
  public/linkray-site/cabinet.html \
  public/linkray-site/cabinet.css \
  public/linkray-site/cabinet.js

if ! git diff --cached --quiet; then
  git commit -m "Fix LinkRay website authentication and real cabinet"
  git push origin HEAD:main
fi

if docker compose version >/dev/null 2>&1; then
  docker compose up -d --build app
else
  docker-compose up -d --build app
fi

sleep 15

STATUS="$(curl -fsS --max-time 20 http://127.0.0.1:3000/api/website/status)"
SESSION="$(curl -fsS --max-time 20 http://127.0.0.1:3000/api/website/auth/session)"
curl -fsSI --max-time 20 http://127.0.0.1:3000/cabinet >/dev/null
curl -fsSI --max-time 20 https://linkray.ru/linkray-site/web-auth.js?v=auth-v1 >/dev/null

echo "$STATUS" | grep -q '"authentication":true'
echo "$SESSION" | grep -q '"authenticated":false'

echo
echo "===================================================="
echo "ВХОД И ЛИЧНЫЙ КАБИНЕТ LINKRAY ПОДКЛЮЧЕНЫ"
echo "ID 1 и 000001 теперь распознаются одинаково"
echo "Резервная копия: $BACKUP_DIR/linkray-auth-before-$STAMP.tar.gz"
echo "Открой linkray.ru в режиме инкогнито"
echo "===================================================="
