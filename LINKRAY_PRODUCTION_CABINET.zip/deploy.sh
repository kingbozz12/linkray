#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_DIR="${1:-/opt/linkray}"
BUNDLE_DIR="$(cd "$(dirname "$0")" && pwd)"
SITE_SOURCE="$BUNDLE_DIR/site"
CABINET_SOURCE="$BUNDLE_DIR/src/linkrayWebCabinet.js"
SITE_TARGET="$PROJECT_DIR/public/linkray-site"
ROUTES_FILE="$PROJECT_DIR/src/linkrayWebsiteRoutes.js"
CABINET_TARGET="$PROJECT_DIR/src/linkrayWebCabinet.js"
BACKUP_ROOT="/root/linkray-production-backups"
STAMP="$(date +%Y%m%d-%H%M%S)"

fail(){ echo; echo "[LinkRay] ОШИБКА: $*" >&2; exit 1; }
log(){ echo; echo "[LinkRay] $*"; }

[ "$(id -u)" -eq 0 ] || fail "Запустите команду от root"
[ -d "$PROJECT_DIR/.git" ] || fail "Не найден проект LinkRay: $PROJECT_DIR"
[ -f "$ROUTES_FILE" ] || fail "Не найден $ROUTES_FILE"
[ -f "$CABINET_SOURCE" ] || fail "В архиве нет backend кабинета"
[ -f "$SITE_SOURCE/index.html" ] || fail "В архиве нет сайта"

mkdir -p "$BACKUP_ROOT"
BACKUP="$BACKUP_ROOT/linkray-production-$STAMP.tar.gz"
log "Создаю резервную копию сайта и маршрутов"
tar -czf "$BACKUP" -C "$PROJECT_DIR" public/linkray-site src/linkrayWebsiteRoutes.js 2>/dev/null || true

log "Устанавливаю реальный backend личного кабинета"
cp "$CABINET_SOURCE" "$CABINET_TARGET"
python3 - "$ROUTES_FILE" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1])
s=p.read_text(encoding='utf-8')
imp="import { installLinkRayWebCabinet } from './linkrayWebCabinet.js';"
if imp not in s:
    s=imp+"\n"+s
call="installLinkRayWebCabinet(app);"
if call not in s:
    marker="export function mountLinkRayWebsiteRoutes(app) {"
    if marker not in s:
        raise SystemExit('Не найдена функция mountLinkRayWebsiteRoutes')
    s=s.replace(marker, marker+"\n  installLinkRayWebCabinet(app);", 1)
s=s.replace("version: 'mobile-v1'", "version: 'production-v1'")
s=s.replace("[LinkRay Website] mobile-v1 routes mounted", "[LinkRay Website] production-v1 routes mounted")
p.write_text(s,encoding='utf-8')
PY

log "Заменяю только файлы сайта"
mkdir -p "$SITE_TARGET"
find "$SITE_TARGET" -mindepth 1 -maxdepth 1 -exec rm -rf {} +
cp -a "$SITE_SOURCE/." "$SITE_TARGET/"
chmod -R u=rwX,go=rX "$SITE_TARGET"

log "Проверяю синтаксис новых файлов"
node --check "$CABINET_TARGET"
node --check "$ROUTES_FILE"
node --check "$SITE_TARGET/app.js"

log "Сохраняю изменения в GitHub"
cd "$PROJECT_DIR"
git add -A -- src/linkrayWebCabinet.js src/linkrayWebsiteRoutes.js public/linkray-site
if ! git diff --cached --quiet; then
  git commit -m "Connect production LinkRay web cabinet"
  git push origin HEAD:main
else
  echo "[LinkRay] Изменения уже установлены"
fi

log "Пересобираю только приложение LinkRay"
if docker compose version >/dev/null 2>&1; then
  docker compose up -d --build app
else
  docker-compose up -d --build app
fi

log "Жду запуска приложения"
for i in $(seq 1 30); do
  if curl -fsS --max-time 5 http://127.0.0.1:3000/api/web/health >/tmp/linkray-web-health.json 2>/dev/null; then
    break
  fi
  sleep 2
done

curl -fsS --max-time 10 http://127.0.0.1:3000/api/web/health | grep -q '"ok":true' || {
  docker logs --tail 120 linkray-app || true
  fail "API личного кабинета не запустился"
}
curl -fsSI --max-time 10 http://127.0.0.1:3000/styles.css | grep -q '200' || fail "styles.css не открывается"
curl -fsSI --max-time 15 https://linkray.ru/ | grep -q '200' || fail "linkray.ru не отвечает"

printf '\n============================================================\n'
printf ' LINKRAY: РЕАЛЬНЫЙ ЛИЧНЫЙ КАБИНЕТ ПОДКЛЮЧЕН\n'
printf ' Вход: ID LinkRay или MAX ID → код приходит в боте\n'
printf ' Данные: реальные каналы, аналитика, посты и AntiFraud\n'
printf ' AntiFraud: включается и выключается с сайта\n'
printf ' Резервная копия: %s\n' "$BACKUP"
printf ' Открой: https://linkray.ru\n'
printf '============================================================\n'
